#include <winsock2.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include <dirent.h>


//#include "timer.h"
#define SERVER "webserver/1.0"
#define PROTOCOL "HTTP/1.1"
#define RFC1123FMT "%a, %d %b %Y %H:%M:%S GMT"
#define PORT 80
#define CMD_SETUP "echo y | timer-tool.exe setup "
#define TIMER_SETUP "timer_setup"
#define OPTION_GROUPS "-g "
  
#include "ctype.h"      
#include <stdlib.h>     
#define MAXLINE 1024     


char *get_mime_type(char *name)
{
  char *ext = strrchr(name, '.');
  if (!ext) return NULL;
  if (strcmp(ext, ".html") == 0 || strcmp(ext, ".htm") == 0) return "text/html";
  if (strcmp(ext, ".jpg") == 0 || strcmp(ext, ".jpeg") == 0) return "image/jpeg";
  if (strcmp(ext, ".gif") == 0) return "image/gif";
  if (strcmp(ext, ".png") == 0) return "image/png";
  if (strcmp(ext, ".css") == 0) return "text/css";
  if (strcmp(ext, ".au") == 0) return "audio/basic";
  if (strcmp(ext, ".wav") == 0) return "audio/wav";
  if (strcmp(ext, ".avi") == 0) return "video/x-msvideo";
  if (strcmp(ext, ".mpeg") == 0 || strcmp(ext, ".mpg") == 0) return "video/mpeg";
  if (strcmp(ext, ".mp3") == 0) return "audio/mpeg";
  return NULL;
}

void send_headers(FILE *f, int status, char *title, char *extra, char *mime, 
                  int length, time_t date)
{
  time_t now;
  char timebuf[128];

  fprintf(f, "%s %d %s\r\n", PROTOCOL, status, title);
  fprintf(f, "Server: %s\r\n", SERVER);
  now = time(NULL);
  strftime(timebuf, sizeof(timebuf), RFC1123FMT, gmtime(&now));
  fprintf(f, "Date: %s\r\n", timebuf);
  if (extra) fprintf(f, "%s\r\n", extra);
  if (mime) fprintf(f, "Content-Type: %s\r\n", mime);
  if (length >= 0) fprintf(f, "Content-Length: %d\r\n", length);
  if (date != -1)
  {
    strftime(timebuf, sizeof(timebuf), RFC1123FMT, gmtime(&date));
    fprintf(f, "Last-Modified: %s\r\n", timebuf);
  }
  fprintf(f, "Connection: close\r\n");
  fprintf(f, "\r\n");
}

void send_error(FILE *f, int status, char *title, char *extra, char *text)
{
  send_headers(f, status, title, extra, "text/html", -1, -1);
  fprintf(f, "<HTML><HEAD><TITLE>%d %s</TITLE></HEAD>\r\n", status, title);
  fprintf(f, "<BODY><H4>%d %s</H4>\r\n", status, title);
  fprintf(f, "%s\r\n", text);
  fprintf(f, "</BODY></HTML>\r\n");
}

void send_file(FILE *f, char *path, struct stat *statbuf)
{
  char data[4096];
  int n;

  FILE *file = fopen(path, "r");
  if (!file)
    send_error(f, 403, "Forbidden", NULL, "Access denied.");
  else
  {
    int length = S_ISREG(statbuf->st_mode) ? statbuf->st_size : -1;
    send_headers(f, 200, "OK", NULL, get_mime_type(path), length, statbuf->st_mtime);

    while ((n = fread(data, 1, sizeof(data), file)) > 0) fwrite(data, 1, n, f);
    fclose(file);
  }
}

struct form_entry{
	char* name;
	char* option;
	char* value;
};
char value1[10]={'\0'};
char value2[10]={'\0'};
char value3[10]={'\0'};
char value4[10]={'\0'};
char value5[10]={'\0'};
char value_d1[10]={'\0'};
char value_u1[10]={'\0'};
char value_d2[10]={'\0'};
char value_u2[10]={'\0'};
char value_d3[10]={'\0'};
char value_u3[10]={'\0'};
char value_d4[10]={'\0'};
char value_u4[10]={'\0'};
char value_d5[10]={'\0'};
char value_u5[10]={'\0'};
char value_d6[10]={'\0'};
char value_u6[10]={'\0'};
char value_d7[10]={'\0'};
char value_u7[10]={'\0'};
char value_d8[10]={'\0'};
char value_u8[10]={'\0'};
char groups[1024]={'\0'};
struct form_entry timer_setup[]={
	{"power_type","-t",value1},
	{"time_unit" ,"-U",value2},
	{"cycles"    ,"-c",value3},
	{"down_time" ,"-d",value4},
	{"up_time"   ,"-u",value5},
	{"down_time1","1d",value_d1},
	{"up_time1" ,"u",value_u1},
	{"down_time2","2d",value_d2},
	{"up_time2" ,"u",value_u2},
	{"down_time3","3d",value_d3},
	{"up_time3" ,"u",value_u3},
	{"down_time4","4d",value_d4},
	{"up_time4" ,"u",value_u4},
	{"down_time5","5d",value_d5},
	{"up_time5" ,"u",value_u5},
	{"down_time6","6d",value_d6},
	{"up_time6" ,"u",value_u6},
	{"down_time7","7d",value_d7},
	{"up_time7" ,"u",value_u7},
	{"down_time8","8d",value_d8},
	{"up_time8" ,"u",value_u8},
	{(char*) 0   ,"-g",groups},
	};

/*--------------------------------------------------------------------*/
void parse_form(struct form_entry* entry_0, char* form)
{
	char* end;
	char* name;
	char* last_name;
	char* cmd_name;
	char* value;
	struct form_entry* entry;
	char cmd_line[1024];
	int len;
	
	cmd_name   = strtok(form,"&");
	value = strchr(cmd_name,'=');
	*value= '\0';
	printf("%s\n",cmd_name);

	do{
		last_name=name;
		name  = strtok(NULL,"&");
		if (name){
			value = strchr(name,'=');
			*value= '\0';
			value++;
//			printf("\n%s,%s",name,value);
			if(*value){
				for(entry = entry_0;*((char*)entry) != 0;entry++){
//					printf("\n:::%s,%s",entry->name,entry->value);
					if(strcmp(entry->name,name) == 0)
						if(strcmp(cmd_name,TIMER_SETUP) == 0) {//setup here
						
							strcpy(entry->value,value);
							value = strchr(entry->value,'%'); //reuse value here , encode '%3A' to ':00'
							if(value){
								*value = ':';
								value++;
								*value = '0';
								value++;
								*value = '0';
							}
						}else
							;//strcpy(entry->value,value);
						
				}
			}
		}
		
	
	}while(name); // remain last entry

	if(strcmp(cmd_name,TIMER_SETUP) == 0) { // pass to command line to do real work
		len = sprintf(cmd_line,CMD_SETUP);
		for(entry = entry_0;entry != entry_0+5;entry++){
			len += sprintf(cmd_line+len,"%s %s ",entry->option,entry->value);
		}
		if(*(entry->value) != '\0' ){ // check groups setting , processed here 
			len += sprintf(cmd_line+len,OPTION_GROUPS);
			for(;*(entry->value) != '\0';entry++){  // parse to 1dxxxuxxx__2dxxxuxxx__......
				len += sprintf(cmd_line+len,"%s%s",entry->option,entry->value);
				entry++;
				len += sprintf(cmd_line+len,"%s%s__",entry->option,entry->value);
			}
		}		
		printf("%s",cmd_line);
		system(cmd_line);	
	}
}
   
DWORD  WINAPI  AnswerThread(LPVOID  lparam)      
{      
	SOCKET  ClientSocket=(SOCKET)(LPVOID)lparam; 
	FILE* read_from;    
 	char* content_type = "text/html";       
	int n;
	int content_length=0;	
	char* form; 
	char* end;  
	time_t timer;
	char time_str[64]={0};
	int file_size=0;
	int len = 0;
	struct stat sb;
	char* method;
	char* path;
	char* protocol;
	   
	char  sendbuf[4096]={0x0};     
	char recvbuf[MAXLINE]={0x0};
	printf("�����ļ�ͷ��ʼ\n"); 
	if(recv(ClientSocket,recvbuf,MAXLINE,0)==SOCKET_ERROR)    
	{    
		printf("���ܴ���");    
	}  
	printf("�����ļ�ͷ����\n"); 
	printf("%s\n",recvbuf); 

	timer=time(NULL);
	strftime(time_str, sizeof(time_str), RFC1123FMT, gmtime(&timer));
	method = strtok(recvbuf, " ");
	path = strtok(NULL, " ");
	path++;  //discard '/'
	protocol = strtok(NULL, "\r");
	

	
	printf("%s;\n%s;\n%s;\n",method,path,protocol);
	
	if(strcmp("POST",method) == 0){ // process form apply
		form=protocol;
		while( *form != '\0') form++; //locate to remain string after protocol
		form++;
		form = strrchr(form, '\n'); //locate to head of form apply
		form++;
		printf("form :\n%s",form);  //debug form apply content
		parse_form(timer_setup, form);    //read or write for form apply
	}
		

	read_from = fopen(path, "r");    
	if(!read_from){    
		printf("���ļ�����");  
		len = sprintf(sendbuf,"%s 404 Not Found\r\n",protocol);     
		len +=sprintf(sendbuf+len,"Server: %s\r\n", SERVER);
		len +=sprintf(sendbuf+len,"Date: %s\r\n", time_str);
		len +=sprintf(sendbuf+len,"Connection: close\r\n");
	 	len +=sprintf(sendbuf+len,"\r\n");
		send(ClientSocket,sendbuf,len,0); 
		return 0;  
	}    
	fstat(fileno(read_from), &sb);
	file_size = sb.st_size;
	
	printf("time: %s\n",time_str);
	printf("file size: %d bytes\n",file_size);  
	len = sprintf(sendbuf,"%s 200 OK\r\n",protocol);     
	len +=sprintf(sendbuf+len,"Content-Type: %s\r\n",content_type); //char-coding=utf-8   
	len +=sprintf(sendbuf+len,"Content-Length: %d\r\n",file_size-107);
	len +=sprintf(sendbuf+len,"Server: %s\r\n", SERVER);
	len +=sprintf(sendbuf+len,"Date: %s\r\n", time_str);
	len +=sprintf(sendbuf+len,"Last-Modified: %s\r\n", time_str);
	len +=sprintf(sendbuf+len,"Connection: close\r\n");
 	len +=sprintf(sendbuf+len,"\r\n");
	send(ClientSocket,sendbuf,len,0); 
	printf("%s\n",path);    
	   

//	while ((n = fread(data, 1, sizeof(data), read_from)) > 0) fwrite(data, 1, n, f);	   
// 	fseek(read_from,0,SEEK_SET);	
 	while((n = fread(sendbuf, 1, sizeof(sendbuf), read_from)) > 0 )    
	{    
		
//		fgets(sendbuf, 1024, read_from); 
		
		printf("%s",sendbuf);   
		send(ClientSocket,sendbuf,n,0);    
		
	}
//	sendbuf[0] = EOF;   
//	send(ClientSocket,sendbuf,1,0);
//	closesocket(ClientSocket);  
	fclose(read_from);    
	return  0;      
}      
   
int main(void)    
{    
	WSADATA              wsaData;    
	SOCKET               ListeningSocket;    
	SOCKET               NewConnection;    
	SOCKADDR_IN          ServerAddr;    
	int                  ClientAddrLen;    
	int                  Port = 6789;    
	int                  Ret;    
	   
	   
	if ((Ret = WSAStartup(MAKEWORD(2,2), &wsaData)) != 0)    
	{    
		printf("��ʼ��winsock�汾���� %d\n", Ret);    
		return -1;    
	}    
	   
	   
	if ((ListeningSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP))     
	== INVALID_SOCKET)    
	{    
		printf("����socket��ʼ������ %d\n", WSAGetLastError());    
		WSACleanup();    
		return -1;    
	}     
	   
	   
	ServerAddr.sin_family = AF_INET;    
	ServerAddr.sin_port = htons(Port);        
	ServerAddr.sin_addr.s_addr = htonl(INADDR_ANY);    
	   
	   
	if (bind(ListeningSocket, (SOCKADDR *)&ServerAddr, sizeof(ServerAddr))     
	== SOCKET_ERROR)    
	{    
		printf("�󶨵�ַ���� %d\n", WSAGetLastError());    
		closesocket(ListeningSocket);    
		WSACleanup();    
		return -1;    
	}    
	   
	   
	if (listen(ListeningSocket, 5) == SOCKET_ERROR)    
	{    
		printf("�������� %d\n", WSAGetLastError());    
		closesocket(ListeningSocket);    
		WSACleanup();    
		return -1;    
	}    
	   
	   
	while(1)      
	{      
	   
		if ((NewConnection = accept(ListeningSocket,NULL,NULL)) == INVALID_SOCKET)    
		{    
			printf("���մ��� %d\n", WSAGetLastError());    
			closesocket(ListeningSocket);    
			WSACleanup();    
			return -1;    
		}     
//		FILE* f;
//		f = fdopen(NewConnection, "r+");
//		printf("%d",f);
//		if (f<0)
//		{    
//			printf("���մ��� %d\n", WSAGetLastError());    
//			closesocket(ListeningSocket);    
//			WSACleanup();    
//			return -1;    
//		}     		  
//		process(f); 	   
	   
		DWORD  dwThreadId;      
		HANDLE  hThread;      
		printf("�����߳̿�ʼ.\n");   
		hThread=CreateThread(NULL,NULL,AnswerThread,(LPVOID)NewConnection,0,&dwThreadId);
		printf("�����߳̽���.\n");   
		      
		if(hThread==NULL)      
		{      
			printf("�����̴߳���.\n");      
		}    
	}    
	return 0;  
}    

